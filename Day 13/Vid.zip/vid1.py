#using openvc read the video file and run it in frame by frame in the python environment

import cv2
import numpy as np

path = "C:\\Users\\STUDENT\\Desktop\\AI\\Videos_AI_ML_13\\vid_mpeg4.mp4"

vid = cv2.VideoCapture(path)

print(vid)
print(vid.isOpened())

while(vid.isOpened()):
    val, frame =  vid.read()
    #if the frame is captured
    if(val):
        gray_im = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
    cv2.imshow('Frame', gray_im)
    if (cv2.waitKey(1)) == ord('q'):
        break
    
vid.release()  #close the object
cv2.destroyAllWindows()