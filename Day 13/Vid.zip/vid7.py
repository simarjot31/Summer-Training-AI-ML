import cv2
import numpy as np
import imutils

#copy the path of the video
#path = 

path="C:\\Users\\STUDENT\\Desktop\\AI\\Videos_AI_ML_13\\VIRAT_S_050201_05_000890_000944.mp4"

#mouse click event
def mouseRGB(event,x,y,flag,param):    
    if(event==cv2.EVENT_FLAG_LBUTTON):
        colorB = frame[x,y,0]
        colorG = frame[x,y,1]
        colorR = frame[x,y,2]
        print('BGR values:' , colorB,colorG,colorR)
        print('corr:',x,y)
        
cv2.namedWindow('Frame')
cv2.setMouseCallback('Frame', mouseRGB)

vid = cv2.VideoCapture(path)
print(vid)
print(vid.isOpened())

frame_counter=0
val, frame = vid.read()
cv2.imshow('Frame',frame)
while(1):
    if(cv2.waitKey(1)==ord('q')):
        break
vid.release() #close the object
cv2.destroyAllWindows()
print(frame_counter)