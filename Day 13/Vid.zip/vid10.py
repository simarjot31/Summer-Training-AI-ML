import cv2
import numpy as np
import imutils

# Define color range for ROI detection in BGR format
lowBGR = np.array([71, 94, 120])
highBGR = np.array([142, 218, 235])

# Initialize the video capture object
vid = cv2.VideoCapture(0)  # Use 0 for default camera, or change to the appropriate camera index

# Check if the video capture object is opened successfully
if not vid.isOpened():
    print("Error: Could not open video device.")
    exit()

frame_counter = 0
xCORR = []
yCORR = []

while True:
    ret, frame = vid.read()
    
    if not ret:
        print("Error: Failed to capture image.")
        break
    
    # Convert frame to HSV color space for better color segmentation
    image_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    
    # Create a mask based on the defined BGR color range
    mask_image = cv2.inRange(image_hsv, lowBGR, highBGR)
    
    # Find contours in the mask image
    cnts = cv2.findContours(mask_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    final_contours = imutils.grab_contours(cnts)
    
    # Draw contours and detect big objects
    for c in final_contours:
        area = cv2.contourArea(c)
        if area > 200:
            M = cv2.moments(c)
            if M['m00'] != 0:
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                cv2.drawContours(frame, [c], -1, (0, 0, 255), 2)
                cv2.circle(frame, (cx, cy), 4, (0, 255, 0), -1)
                xCORR.append(cx)
                yCORR.append(cy)
                for i in range(len(xCORR)):
                    frame[yCORR[i], xCORR[i]] = (0, 0, 255)
    
    # Display the frame with detected contours
    cv2.imshow('Frame', frame)
    
    # Check for 'q' key press to exit the loop
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close all windows
vid.release()
cv2.destroyAllWindows()
