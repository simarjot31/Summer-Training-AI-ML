import cv2
import numpy as np

path = "C:\\Users\\STUDENT\\Desktop\\AI\\Videos_AI_ML_13\\vid_mpeg4.mp4"

vid = cv2.VideoCapture(path)

print(vid)
print(vid.isOpened())

frame_counter = 0

while(vid.isOpened()):
    val, frame =  vid.read()
    frame_counter += 1
    
    #if the frame is captured
    if(val):
        gray_im = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        ycbcr_im = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        hsv_im = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
    cv2.imshow('Frame', gray_im)
    cv2.imshow('HSV',hsv_im)
    cv2.imshow('YCRCB', ycbcr_im)
    cv2.imshow('Original', frame)
    if (cv2.waitKey(1)) == ord('q'):
        break
    
vid.release()  #close the object
cv2.destroyAllWindows()

print(frame_counter)